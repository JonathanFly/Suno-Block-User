# Suno-Block-User
Suno Block User Chrome Extension

## Features
- Block User Songs (On Suno Home Page) 
- Block User Notifications (But Not Comments)

## How To Install
1. **Download** [`Suno‑Block‑User_1.0.zip`](./Suno-Block-User_1.0.zip).
2. **Extract** the ZIP—remember where the folder is.
3. In Chrome, open `chrome://extensions` and switch **Developer mode** **ON** (top‑right toggle).
4. Click **Load unpacked** → choose the folder you just extracted.
5. The *Suno‑Block‑User* icon should now appear; pin or enable it if needed.

## How To Use
- Click Extension Icon for the menu
- Users can be added to list in menu, or blocked with mute icon on the page.

**Why Build This?**
I needed a small test project to compare AIs and the Suno Discord suggested this. I don't personally need to block users on Suno. (All the AIs did well but DeepSeek was first to working code, though less ambitious. Still needed way too much human debugging and all the AIs got hung up on Suno website code.) 

**Is this Extension allowed?** 
I believe it's allowed. While the Suno ToS prohibits "data mining, robots, scraping, or similar data gathering or extraction methods" and there is no official Suno API, this extension doesn't access anything itself. It just sits in the background passively and removes block users' songs and notifications from the web page.

**Why use the Dexie library?**
Because this Extension was extracted from a more complicated project and I didn't bother to strip it out.